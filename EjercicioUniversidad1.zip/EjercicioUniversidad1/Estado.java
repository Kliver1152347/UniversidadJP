
/**
 * Enumeration class Estado - write a description of the enum class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public enum Estado {
    ASIGNADO,ENTREGADO,RECHAZADO
}
